﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal class Musica : Midia
    {
        public string? Artista { get; set; }

        public override void Reproduzir()
        {
            MessageBox.Show($"Tocando música: {Titulo} de {Artista}");
        }

    }
}
