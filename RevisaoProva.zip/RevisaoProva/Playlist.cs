﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal class Playlist
    {
        public List<Midia> Midias { get; set; } = new List<Midia>();

     public void AdicionarMidia(Midia m)
        {
            Midias.Add(m);
        }
        public void RemoverMidia(Midia m)
        {
            Midias.Remove(m);
        }
        public void ExibirPlaylist()
        {
            string show = "";
            foreach (Midia m in Midias) 
            {
                show = $"";
            };
        }

    }
}
