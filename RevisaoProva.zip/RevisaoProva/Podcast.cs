﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal class Podcast : Midia
    {
        private string? apresentador;

        public string? Apresentador { get => apresentador; set => apresentador = value; }

        public override void Reproduzir()
        {
            MessageBox.Show($"Reproduzindo podcast: {Titulo} com {Apresentador}");
        }
    }
}
