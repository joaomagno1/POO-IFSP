﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoProva
{
    internal abstract class Midia
    {
        string titulo;
        int duracao;

        public string Titulo { get => titulo; set => titulo = value; }
        public int Duracao { get => duracao; set => duracao = value; }

        public abstract void Reproduzir();
    }
}
