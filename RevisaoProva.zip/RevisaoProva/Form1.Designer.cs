﻿namespace RevisaoProva
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            Playlist = new TabPage();
            tabPage2 = new TabPage();
            label1 = new Label();
            label2 = new Label();
            txtTitulo = new TextBox();
            txtArtista = new TextBox();
            btnAdc = new Button();
            txtApresentador = new TextBox();
            txtTituloPodc = new TextBox();
            label3 = new Label();
            label4 = new Label();
            tabControl1.SuspendLayout();
            Playlist.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Playlist);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(130, 54);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(507, 240);
            tabControl1.TabIndex = 0;
            // 
            // Playlist
            // 
            Playlist.Controls.Add(btnAdc);
            Playlist.Controls.Add(txtArtista);
            Playlist.Controls.Add(txtTitulo);
            Playlist.Controls.Add(label2);
            Playlist.Controls.Add(label1);
            Playlist.Location = new Point(4, 24);
            Playlist.Name = "Playlist";
            Playlist.Padding = new Padding(3);
            Playlist.Size = new Size(499, 212);
            Playlist.TabIndex = 0;
            Playlist.Text = "Música";
            Playlist.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(txtApresentador);
            tabPage2.Controls.Add(txtTituloPodc);
            tabPage2.Controls.Add(label3);
            tabPage2.Controls.Add(label4);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(499, 212);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Podcast";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 14);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 1;
            label1.Text = "Titulo:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 111);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 2;
            label2.Text = "Artista:";
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(6, 32);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(100, 23);
            txtTitulo.TabIndex = 1;
            // 
            // txtArtista
            // 
            txtArtista.Location = new Point(6, 129);
            txtArtista.Name = "txtArtista";
            txtArtista.Size = new Size(100, 23);
            txtArtista.TabIndex = 3;
            // 
            // btnAdc
            // 
            btnAdc.Location = new Point(398, 129);
            btnAdc.Name = "btnAdc";
            btnAdc.Size = new Size(75, 60);
            btnAdc.TabIndex = 1;
            btnAdc.Text = "Salvar";
            btnAdc.UseVisualStyleBackColor = true;
            // 
            // txtApresentador
            // 
            txtApresentador.Location = new Point(6, 123);
            txtApresentador.Name = "txtApresentador";
            txtApresentador.Size = new Size(100, 23);
            txtApresentador.TabIndex = 7;
            // 
            // txtTituloPodc
            // 
            txtTituloPodc.Location = new Point(6, 26);
            txtTituloPodc.Name = "txtTituloPodc";
            txtTituloPodc.Size = new Size(100, 23);
            txtTituloPodc.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 108);
            label3.Name = "label3";
            label3.Size = new Size(81, 15);
            label3.TabIndex = 6;
            label3.Text = "Apresentador:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 11);
            label4.Name = "label4";
            label4.Size = new Size(40, 15);
            label4.TabIndex = 5;
            label4.Text = "Titulo:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Form1";
            tabControl1.ResumeLayout(false);
            Playlist.ResumeLayout(false);
            Playlist.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage Playlist;
        private Label label1;
        private TabPage tabPage2;
        private Button btnAdc;
        private TextBox txtArtista;
        private TextBox txtTitulo;
        private Label label2;
        private TextBox txtApresentador;
        private TextBox txtTituloPodc;
        private Label label3;
        private Label label4;
    }
}
